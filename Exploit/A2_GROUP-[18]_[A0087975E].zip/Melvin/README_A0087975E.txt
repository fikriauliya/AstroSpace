========== Class of Vulnerability: Weak Password Checker (18) ==========
* Goal: Crack a user's password by brute force
* Exploit verification: Adversary log into victim's account
* The exploit is NOT automatated
* Exploit steps: By guessing dictionary word of a valid user account with some modification of guess such as changing 'o' to '0' and 'a' to '@'. Possible guesses : password, p@ssw0rd, p@ssword, P@ssw0rd and etc. Can use online ready website password cracker to do the operation as the website does not limit the number of login attempts.

========== Class of Vulnerability: Logic Authentication Flaw - Privilege Escalation (19) ==========
User accounts => password:
user0@email.com => passw0rd (admin)
user1@email.com => passw0rd (admin)

* Goal: A non-administrator user deletes another user's comment.
* Exploit verification: Victim's comment has been successfully deleted
* The exploit is NOT automatated
* Exploit steps: Login into an administrator account in one of the tab, go to 'Settings >> Admin Area', find a user with comments to allow the delete operation to take place. Click on the 'Delete Comment' button to be open on a new tab, logout of admin on the tab which does not have the option to delete comments. Use that tab that is just logout and log into a non-administrator account and go back to the tab that has the delete operation. Click on the comment that you wish to delete, and the comment will be successfully deleted. Verify by going to the user that belongs to the comment and check if the comment has been deleted.

========== Class of Vulnerability: Parameter Tempering (20) ==========
* Goal: Send a message to a user who is not a friend to the attacker
* Exploit verification: Check the non-friend user has receive the message sent by the attacker
* The exploit is NOT automatated
* Exploit steps: Compose a message, open the 'Inspect Element' on the dropdown box, under the form control "recipient", change the "option value" to another valid user id. (i.e. option value = "11") and proceed to send out the message by clicking on the send button. The message will be send to user2 who is associated with the user id of '11'.

========== Class of Vulnerability: Parameter Pollution (21) ==========
* Goal: The bug changes the information of intended target from a non-intended target.
* Exploit verification: Check if the intended target user information has change.
* The exploit is NOT automatated
* Exploit steps: Log in as admin user, go to "Setting >> Admin Area", "Inspect Element" on the use that you wish to change the information from. Under "href="https://localhost/admin/edit-info/?user_id=15"" and append the user id of the intend user that you wish to change the information at the back of the address. (i.e. &user_id=14)

======================================================  END  ========================================================
