# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Websecurity::Application.config.secret_key_base = '230d74d22c10d928e3edb13e26039d3428ad152e591afe985fc55965b0d28f8a2282c07809f568631a4f0a93f28425b1056da14b78ed3feeb41f69375217854d'
