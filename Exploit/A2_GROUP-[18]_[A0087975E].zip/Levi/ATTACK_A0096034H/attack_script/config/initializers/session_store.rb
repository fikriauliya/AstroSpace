# Be sure to restart your server when you modify this file.

Websecurity::Application.config.session_store :cookie_store, key: '_websecurity_session'
