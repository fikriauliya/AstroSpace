require 'test_helper'

class AttacksHelperTest < ActionView::TestCase
end
