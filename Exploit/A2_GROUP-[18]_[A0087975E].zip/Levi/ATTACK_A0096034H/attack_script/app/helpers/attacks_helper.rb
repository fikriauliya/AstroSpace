module AttacksHelper
end
