class AttacksController < ApplicationController
  after_action :allow_iframe, only: :clickjacking

  def clickjacking
    @ip = params[:ip]
  end

  def no_csrf
    @id = params[:id]
    @ip = params[:ip]
  end

  def allow_iframe
    response.headers.except! 'X-Frame-Options'
  end
end
